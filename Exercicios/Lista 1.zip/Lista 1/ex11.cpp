#include <iostream>
using namespace std;

int main (){
	
	//Um abaixo do outro
	for (int i = 0; i <= 20; i++){
		cout << i << endl;
	}
	
	cout << endl;
	//Um ao lado do outro
		for (int i = 0; i <= 20; i++){
		cout << i;
	}
	
	
	return 0;
}
